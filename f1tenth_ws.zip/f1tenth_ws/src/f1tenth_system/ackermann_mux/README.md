ackermann_mux
=========

based on twist_mux
Ackermann multiplexer with support for
[ackermann_msgs/AckermannDriveStamped](http://docs.ros.org/api/ackermann_msgs/html/msg/AckermannDriveStamped.html)
topics and
[std_msgs/Bool](http://docs.ros.org/api/std_msgs/html/msg/Bool.html) locks with priorities.

<!-- See [documentation](http://wiki.ros.org/twist_mux). -->