^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package asio_cmake_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.0 (2022-03-20)
------------------

1.1.0 (2022-03-20)
------------------

1.0.1 (2021-08-30)
------------------
* Export ASIO definitions (`#44 <https://github.com/ros-drivers/transport_drivers/issues/44>`_)
* Deduplicate ASIO CMake module (`#43 <https://github.com/ros-drivers/transport_drivers/issues/43>`_)
  * Added ASIO CMake module
  * Use asio_cmake_module
* Contributors: Esteve Fernandez

0.0.6 (2020-08-27)
------------------

0.0.5 (2020-07-16)
------------------

0.0.4 (2019-12-12)
------------------

0.0.3 (2019-08-21)
------------------

0.0.2 (2019-08-19)
------------------
