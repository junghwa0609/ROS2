* **IO Context**

A library to write synchronous and asynchronous networking applications.