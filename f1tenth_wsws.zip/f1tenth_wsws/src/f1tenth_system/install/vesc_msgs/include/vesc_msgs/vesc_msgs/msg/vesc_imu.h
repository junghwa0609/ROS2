// generated from rosidl_generator_c/resource/idl.h.em
// with input from vesc_msgs:msg/VescImu.idl
// generated code does not contain a copyright notice

#ifndef VESC_MSGS__MSG__VESC_IMU_H_
#define VESC_MSGS__MSG__VESC_IMU_H_

#include "vesc_msgs/msg/detail/vesc_imu__struct.h"
#include "vesc_msgs/msg/detail/vesc_imu__functions.h"
#include "vesc_msgs/msg/detail/vesc_imu__type_support.h"

#endif  // VESC_MSGS__MSG__VESC_IMU_H_
