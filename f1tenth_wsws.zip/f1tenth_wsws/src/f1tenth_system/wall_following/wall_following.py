import rclpy
from rclpy.node import Node
import numpy as np
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped

class WallFollowNode(Node):
    def __init__(self):
        super().__init__('wall_follow_node')
        self.drive_pub = self.create_publisher(AckermannDriveStamped, '/drive', 10)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.scan_callback, 10)
        self.desired_distance = 1.0  # 벽과의 목표 거리 (미터)
        self.kp = 1.0  # 비례 제어 게인

    def scan_callback(self, scan_msg):
        ranges = np.array(scan_msg.ranges)
        angles = np.linspace(scan_msg.angle_min, scan_msg.angle_max, len(ranges))
        
        # 왼쪽 90도(π/2)와 60도(π/3) 방향의 거리값 추출
        left_90_idx = np.argmin(np.abs(angles - np.pi/2))
        left_60_idx = np.argmin(np.abs(angles - np.pi/3))
        dist_90 = ranges[left_90_idx]
        dist_60 = ranges[left_60_idx]
        
        # 벽과의 각도 계산 (삼각법)
        alpha = np.arctan2(dist_90 * np.cos(np.pi/3 - np.pi/2) - dist_60, dist_90 * np.sin(np.pi/3 - np.pi/2))
        # 벽까지의 거리 예측
        dist_to_wall = dist_90 * np.cos(alpha)
        
        # 오차 계산
        error = self.desired_distance - dist_to_wall
        
        # 비례 제어로 조향각 계산
        steering_angle = self.kp * error
        steering_angle = np.clip(steering_angle, -0.4, 0.4)  # 최대 조향 제한
        
        # 속도는 일정하게(혹은 조향에 따라 감속)
        speed = 1.0 if abs(steering_angle) < 0.2 else 0.5
        
        # 드라이브 명령 퍼블리시
        drive_msg = AckermannDriveStamped()
        drive_msg.drive.steering_angle = steering_angle
        drive_msg.drive.speed = speed
        self.drive_pub.publish(drive_msg)
        self.get_logger().info(f"Error: {error:.2f}, Steering: {steering_angle:.2f}")

def main(args=None):
    rclpy.init(args=args)
    node = WallFollowNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

